import Todo from "./Components/ToDo/Todo"

const App = () => {
  return (
    <>
      <Todo/>
    </>
  )
}

export default App